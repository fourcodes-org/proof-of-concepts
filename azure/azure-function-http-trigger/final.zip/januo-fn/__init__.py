import logging
import json
import azure.functions as func

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    # Handle GET request
    if req.method == 'GET':
        return handle_get(req)

    # Handle POST request
    elif req.method == 'POST':
        return handle_post(req)

    # Handle other methods
    else:
        return func.HttpResponse("Method not allowed", status_code=405)

def handle_get(req: func.HttpRequest) -> func.HttpResponse:
    return func.HttpResponse(
        json.dumps({
            'method': req.method,
            'url': req.url,
            'headers': dict(req.headers),
            'params': dict(req.params),
            'get_body': req.get_body().decode()
        })
    )

def handle_post(req: func.HttpRequest) -> func.HttpResponse:
    try:
        req_body = req.get_json()
        return func.HttpResponse(
            json.dumps({
                'method': req.method,
                'url': req.url,
                'headers': dict(req.headers),
                'params': dict(req.params),
                'post_body': req_body
            })
        )
    except ValueError:
        return func.HttpResponse("Invalid JSON payload", status_code=400)
